import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MenuComponent } from './menu/menu.component';
import { ClaimComponent } from './claim/claim.component';
import { PolicyComponent } from './policy/policy.component';
import { RenewComponent } from './policy/renew/renew.component';
import { ViewstatusComponent } from './policy/viewstatus/viewstatus.component';
import { VehicleComponent } from './vehicle/vehicle.component';
import { ViewvehicleComponent } from './vehicle/viewvehicle/viewvehicle.component';
import { AccountsComponent } from './accounts/accounts.component';
import { ProfileComponent } from './accounts/profile/profile.component';
import { LogoutComponent } from './accounts/logout/logout.component';
import { LoginComponent } from './login/login/login.component';
import { LoginGuard } from 'src/app/utility/loginguard';
import * as countries from './countries.json'

const routes: Routes = [{
    path: 'Login',
    component: LoginComponent
  },
  {
  path: 'Menu',
  component: MenuComponent,
  canActivate: [LoginGuard],
  canActivateChild: [LoginGuard],
  children:[
    {
      path: 'Claim',
      component: ClaimComponent,
      loadChildren: () => import('./claim/claim.module')
        .then(m => m.ClaimModule)
    },
    {
      path: 'Policy',
      component: PolicyComponent,
      children:[
        {
          path: 'Renew',
          component: RenewComponent
        },
        {
          path: 'ViewStatus',
          component: ViewstatusComponent,
          data: countries
        }]
    },
    {
      path: 'Vehicle',
      component: VehicleComponent,
      children:[
        {
          path: 'ViewVehicle',
          component: ViewvehicleComponent
        }]
    },
    {
      path: 'Accounts',
      component: AccountsComponent,
      children:[
        {
          path: 'Profile',
          component: ProfileComponent
        },
        {
          path: 'Logout',
          component: LogoutComponent
        },
      ]
    }
  ]
},
{ path: '', redirectTo: '/Login', pathMatch: 'full' },
{ path: '**', redirectTo: '/Login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
