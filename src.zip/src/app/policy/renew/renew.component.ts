import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-renew',
  templateUrl: './renew.component.html',
  styleUrls: ['./renew.component.css']
})
export class RenewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
