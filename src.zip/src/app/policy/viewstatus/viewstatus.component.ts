import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { EditComponent } from 'src/app/policy/viewstatus/edit/edit.component';

@Component({
  selector: 'app-viewstatus',
  templateUrl: './viewstatus.component.html',
  styleUrls: ['./viewstatus.component.css']
})
export class ViewstatusComponent implements OnInit, AfterViewInit {
  countryData: any;
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  displayedColumns: string[] = ['name', 'capital', 'population', 'nativeName', 'edit', 'delete'];
  tableSource = new MatTableDataSource();
  
  constructor(private route: ActivatedRoute,
    private matdialog: MatDialog) { }

  ngOnInit(): void {
    this.countryData = this.route.snapshot.data.default;
    console.log(this.countryData);
    this.tableSource.data = this.countryData;
  }

  ngAfterViewInit(): void{
    this.tableSource.paginator = this.paginator;
    this.tableSource.sort = this.sort;
  }

  openDialog(data: any): void {
    const dialogRef = this.matdialog.open(EditComponent, {
      width: '500px',
      data: {
        name: data.name,
        capital: data.capital,
        population: data.population,
        region: data.nativeName
      }      
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      this.updateRowData(result);
    });
  }

  updateRowData(row_obj) {
    this.tableSource.data = this.tableSource.data.filter((value:any)=>{
      if(value.name == row_obj.name){
        value.capital = row_obj.capital;
        value.population=row_obj.population;
        value.region=row_obj.region;
      }
      return true;
    });
  }
}
