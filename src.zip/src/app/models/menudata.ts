import {Item, Menu} from "./menu";

export const MenuData:Menu[] = [new Menu('Claim', 'pi pi-plus', [
    new Item('Create', 'pi pi-save', 'Claim/Create'),
    new Item('Edit', 'pi pi-pencil', 'Claim/Edit'),
    new Item('View', 'pi pi-info', 'Claim/View')], 'Claim'),

    new Menu('Policy', 'pi pi-plus', [
        new Item('Renew', 'pi pi-pencil', 'Policy/Renew'),
        new Item('View Status', 'pi pi-info', 'Policy/ViewStatus')], 'Policy'),

    new Menu('Vehicle', 'pi pi-plus', [
        new Item('View', 'pi pi-check-circle', 'Vehicle/ViewVehicle')], 'Vehicle'),

    new Menu('Accounts', 'pi pi-plus', [
        new Item('My Profile', 'pi pi-user', 'Accounts/Profile'),
        new Item('Log Out', 'pi pi-sign-out', 'Accounts/Logout')], 'Accounts')
];