export const Purpose:any[]=[
    "Business",
    "Trip",
    "Pilgrimage"
];