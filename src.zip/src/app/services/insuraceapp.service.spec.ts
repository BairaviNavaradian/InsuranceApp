import { TestBed } from '@angular/core/testing';

import { InsuraceappService } from './insuraceapp.service';

describe('InsuraceappService', () => {
  let service: InsuraceappService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InsuraceappService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
