import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewvehicle',
  templateUrl: './viewvehicle.component.html',
  styleUrls: ['./viewvehicle.component.css']
})
export class ViewvehicleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
